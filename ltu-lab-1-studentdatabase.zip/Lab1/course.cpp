#include "pch.h"
#include "course.h"


Course::Course(std::string name) : name(name) { }

Course::~Course() { }

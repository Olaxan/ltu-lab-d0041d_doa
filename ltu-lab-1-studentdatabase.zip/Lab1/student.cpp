#include "pch.h"
#include "student.h"


Student::Student(std::string name) : name(name) { }

Student::~Student() { }

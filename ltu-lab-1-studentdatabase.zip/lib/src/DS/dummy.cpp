#include "stdafx.h"
#include "lnklist_d.h"
#include "sarray.h"

//Ensure VS creates libriaries properly.